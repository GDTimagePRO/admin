CREATE DATABASE  IF NOT EXISTS `genesys_core` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `genesys_core`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: genesys_core
-- ------------------------------------------------------
-- Server version	5.5.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `barcodes`
--

DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barcodes` (
  `barcode` varchar(64) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_json` text NOT NULL,
  `master` enum('Y','N') NOT NULL DEFAULT 'N',
  `date_used` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customer_id`,`barcode`),
  UNIQUE KEY `barcode` (`customer_id`,`barcode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `batch_import_queue`
--

DROP TABLE IF EXISTS `batch_import_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_import_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_item_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `barcode` varchar(45) NOT NULL,
  `external_order_id` int(11) NOT NULL,
  `external_system_name` varchar(45) NOT NULL,
  `data` blob NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11674 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_key` varchar(45) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `config_json` text NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `key_UNIQUE` (`id_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `default_design_templates`
--

DROP TABLE IF EXISTS `default_design_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_design_templates` (
  `product_type_id` int(11) NOT NULL,
  `design_template_id` int(11) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY (`product_type_id`),
  UNIQUE KEY `product_type_id_UNIQUE` (`product_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `design_template_categories`
--

DROP TABLE IF EXISTS `design_template_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `design_template_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `design_templates`
--

DROP TABLE IF EXISTS `design_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `design_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_type_id` int(11) NOT NULL,
  `config_json` text NOT NULL,
  `design_json` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=872 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `designs`
--

DROP TABLE IF EXISTS `designs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_item_id` int(11) NOT NULL,
  `product_type_id` int(11) NOT NULL,
  `config_json` text NOT NULL,
  `design_json` longtext,
  `date_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'See Design constants',
  `product_id` int(11) NOT NULL DEFAULT '0',
  `date_rendered` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92047 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `designs_state_names`
--

DROP TABLE IF EXISTS `designs_state_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designs_state_names` (
  `value` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`value`),
  UNIQUE KEY `id_UNIQUE` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `barcode` varchar(32) NOT NULL,
  `processing_stages_id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_json` text NOT NULL,
  `external_order_id` bigint(20) NOT NULL DEFAULT '0',
  `external_order_status` int(11) NOT NULL DEFAULT '0',
  `external_user_id` int(11) NOT NULL,
  `external_system_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `processingstages_id` (`processing_stages_id`),
  KEY `barcode_id` (`barcode`),
  KEY `order_id` (`processing_stages_id`,`barcode`)
) ENGINE=MyISAM AUTO_INCREMENT=63824 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_items_processing_stage_names`
--

DROP TABLE IF EXISTS `order_items_processing_stage_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items_processing_stage_names` (
  `value` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`value`),
  UNIQUE KEY `value_UNIQUE` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `order_lookup`
--

DROP TABLE IF EXISTS `order_lookup`;
/*!50001 DROP VIEW IF EXISTS `order_lookup`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `order_lookup` (
  `customer_name` varchar(255),
  `external_system` varchar(45),
  `external_oid` bigint(20),
  `genesys_oid` int(11),
  `design_id` int(11),
  `barcode` varchar(32),
  `processing_stage` int(11),
  `design_state` int(11),
  `date_created` timestamp,
  `date_rendered` timestamp,
  `product_id` int(11),
  `product_name` varchar(128)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `plastic_categories`
--

DROP TABLE IF EXISTS `plastic_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plastic_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material` varchar(20) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(16) NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `long_name` varchar(128) NOT NULL,
  `category_id` int(11) NOT NULL,
  `allow_graphics` tinyint(1) NOT NULL,
  `shape_id` varchar(32) NOT NULL DEFAULT 'Rectangular',
  `frame_width` float NOT NULL DEFAULT '0',
  `frame_height` float NOT NULL DEFAULT '0',
  `product_type_id` int(11) NOT NULL,
  `color_model` varchar(255) NOT NULL DEFAULT '1_BIT',
  `config_json` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=376 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `products_category`
--

DROP TABLE IF EXISTS `products_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `data` blob,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shipping_information`
--

DROP TABLE IF EXISTS `shipping_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `address_1` varchar(90) NOT NULL,
  `address_2` varchar(90) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state_province` varchar(45) NOT NULL,
  `zip_postal_code` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `workstation_table`
--

DROP TABLE IF EXISTS `workstation_table`;
/*!50001 DROP VIEW IF EXISTS `workstation_table`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `workstation_table` (
  `d_id` int(11),
  `d_state` int(11),
  `d_date_rendered` timestamp,
  `dsn_name` varchar(45),
  `oi_id` int(11),
  `oi_customer_id` int(11),
  `oi_processing_stages_id` int(11),
  `oi_date_created` timestamp,
  `oi_external_order_id` bigint(20),
  `oi_external_system_name` varchar(45),
  `oipsn_name` varchar(45),
  `p_category_id` int(11),
  `pc_name` varchar(64),
  `c_description` varchar(255)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'genesys_core'
--

--
-- Dumping routines for database 'genesys_core'
--

--
-- Final view structure for view `order_lookup`
--

/*!50001 DROP TABLE IF EXISTS `order_lookup`*/;
/*!50001 DROP VIEW IF EXISTS `order_lookup`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `order_lookup` AS select `c`.`description` AS `customer_name`,`oi`.`external_system_name` AS `external_system`,`oi`.`external_order_id` AS `external_oid`,`d`.`order_item_id` AS `genesys_oid`,`d`.`id` AS `design_id`,`oi`.`barcode` AS `barcode`,`oi`.`processing_stages_id` AS `processing_stage`,`d`.`state` AS `design_state`,`oi`.`date_created` AS `date_created`,`d`.`date_rendered` AS `date_rendered`,`d`.`product_id` AS `product_id`,`p`.`long_name` AS `product_name` from (((`order_items` `oi` join `designs` `d`) join `customers` `c`) join `products` `p`) where ((`oi`.`id` = `d`.`order_item_id`) and (`c`.`id` = `oi`.`customer_id`) and (`p`.`id` = `d`.`product_id`)) order by `c`.`id`,`oi`.`external_system_name`,`oi`.`id`,`d`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `workstation_table`
--

/*!50001 DROP TABLE IF EXISTS `workstation_table`*/;
/*!50001 DROP VIEW IF EXISTS `workstation_table`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `workstation_table` AS select `d`.`id` AS `d_id`,`d`.`state` AS `d_state`,`d`.`date_rendered` AS `d_date_rendered`,`dsn`.`name` AS `dsn_name`,`oi`.`id` AS `oi_id`,`oi`.`customer_id` AS `oi_customer_id`,`oi`.`processing_stages_id` AS `oi_processing_stages_id`,`oi`.`date_created` AS `oi_date_created`,`oi`.`external_order_id` AS `oi_external_order_id`,`oi`.`external_system_name` AS `oi_external_system_name`,`oipsn`.`name` AS `oipsn_name`,`p`.`category_id` AS `p_category_id`,`pc`.`name` AS `pc_name`,`c`.`description` AS `c_description` from ((((((`designs` `d` join `products` `p`) join `order_items` `oi`) join `products_category` `pc`) join `designs_state_names` `dsn`) join `order_items_processing_stage_names` `oipsn`) join `customers` `c`) where ((`dsn`.`value` = `d`.`state`) and (`oipsn`.`value` = `oi`.`processing_stages_id`) and (`d`.`order_item_id` = `oi`.`id`) and (`d`.`product_id` = `p`.`id`) and (`p`.`category_id` = `pc`.`id`) and (`c`.`id` = `oi`.`customer_id`)) order by `oi`.`external_order_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-09-14 16:52:55
